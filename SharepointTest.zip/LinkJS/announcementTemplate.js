(function () {
	// var jsToBeImported = ["jquery-3.5.1.min.js", "popper.min.js", "bootstrap.min.js"];
// 	for (var i = 0; i < jsToBeImported.length; i++){
// 		var scrEle = document.createElement('script');
// 		scrEle.setAttribute("src", "http://192.168.0.104:10001/siteAssets/" + jsToBeImported[i]);
// 		document.head.appendChild(scrEle);
// 	}

	let _scriptsToLoad = [
  		"jquery-3.5.1.min.js", "popper.min.js", "bootstrap.min.js"
	];

	function createScriptElement(i) {
	  if (i == _scriptsToLoad.length) return;
	  let script = _scriptsToLoad[i];
	  let js = document.createElement('script');
	  js.src =  "http://192.168.0.104:10001/siteAssets/" + script;
	  js.onload = function(){createScriptElement(i+1)};
	  document.head.append(js);
	}
	
	createScriptElement(0);
	
 	var overrideContext = {};

	overrideContext.Templates = {};

	overrideContext.Templates.Header = overrideHeader;

	overrideContext.Templates.Body = overrideTemplate;

	SPClientTemplates.TemplateManager.RegisterTemplateOverrides(overrideContext);
})();

function changeAnnouncements(e){
	if (e.currentTarget.innerHTML == "▼ Show")
		e.currentTarget.innerHTML = "▲ Hide";
	else if (e.currentTarget.innerHTML == "▲ Hide")
		e.currentTarget.innerHTML = "▼ Show";
}

function overrideHeader(ctx) {
	return '<link rel="stylesheet" href="http://192.168.0.104:10001/siteAssets/announcements.css">'+
		'<link rel="stylesheet" href="http://192.168.0.104:10001/siteAssets/bootstrap.min.css">';
}

function overrideTemplate(ctx) {
	body = '<div class="divTable topazCells">' +
			'<div class="divTableHeader">Announcements</div>' +
			'<div class="divTableBody">';
	for (var i = 0; i < 3; i++) {
		if (i == ctx.ListData.Row.length) break;
		body += '<div class="divTableRow"><div class="divTableCell"><span class="red-right-arrow">▶</span><a href="javascript:" onclick="alert(\''+ctx.ListData.Row[i].Description+'\')">' + ctx.ListData.Row[i].Title + '</a></div></div>';
	}
	body += '<div id="collapseAnnounments" class="collapse">';
	for (var i = 3; i < ctx.ListData.Row.length; i++) {
		body += '<div class="divTableRow"><div class="divTableCell"><span class="red-right-arrow">▶</span><a href="javascript:" onclick="alert(\''+ctx.ListData.Row[i].Description+'\')">' + ctx.ListData.Row[i].Title + '</a></div></div>';
	}
	body += '</div>'+
			'</div>' +
			'</div>';
	body += '<div><a class="button collapse-button" onclick="changeAnnouncements(event)" data-toggle="collapse" href="#collapseAnnounments" role="button" aria-expanded="false" aria-controls="collapseAnnounments">▼ Show</a><div>';
	return body;
}