(function () {
    function customTitle(ctx) {
        //console.log(ctx);
        return "<div style='display: flex; align-items: center; border: 3px #eee solid; border-top: 0px; border-bottom: 0px; padding: 1rem 2rem'; font-size: 16px>" +
            "<span style='display:inline-block; width: 0;" +
            "height: 0;" +
            "border-style: solid;" +
            "border-width: 7px 0 7px 14px;" +
            "border-color: transparent transparent transparent #ff0000; margin-right: 2rem'></span>" + ctx.Title + "</div>";
    }

    function customHeader(ctx) {
        return '<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">' +
            "<div style='position: relative;'><h1 style='background-color: red; text-align: center; font-weight: 100; font-size: 20px; padding: 15px; color: white; margin: 0px;'>" + ctx.ListTitle + "</h1>";
    }

    function customBody(ctx) {
        console.log("body", ctx);
        var body = "<div>";
        for (var i = 0; i < 3; i++) {
            if (ctx.ListData.Row[i] != undefined)
                body += customTitle(ctx.ListData.Row[i]);
        }
        body += "</div>";
        if (ctx.ListData.Row.length > 3) {
            body += '<style>\n' +
                '.closed {' +
                'display: none' +
                '}\n' +
                '.opened {' +
                'display: inline-block' +
                '}\n' +
                '#collapseAnnounments.collapse ~a .closed {' +
                'display: inline-block' +
                '}\n' +
                '#collapseAnnounments.collapse ~a .opened {' +
                'display: none' +
                '}\n' +
                '#collapseAnnounments.collapse.show ~a .closed {' +
                'display: none' +
                '}\n' +
                '#collapseAnnounments.collapse.show ~a .opened {' +
                'display: inline-block' +
                '}\n' +
                '</style>';
            var cbody = '<div class="collapse" id="collapseAnnounments">';
            for (var i = 3; i < ctx.ListData.Row.length; i++) {
                cbody += customTitle(ctx.ListData.Row[i]);
            }

            cbody += '</div>';
            body += cbody;
            body += '<a style="position: absolute;' +
                'bottom: -30px;' +
                'left: 50%;' +
                'transform: translateX(-50%);' +
                'background-color: #aaa;' +
                'min-width: 10vw;' +
                'display: flex;' +
                'justify-content: center;' +
                'align-items: center;' +
                'padding: 5px 10px;' +
                'border-bottom-left-radius: 5px;' +
                'border-bottom-right-radius: 5px;' +
                'color: white;' +
                'text-decoration: none;" class="" type="button" data-toggle="collapse" data-target="#collapseAnnounments" aria-expanded="false" aria-controls="collapseAnnounments">';
            body += '<span class="closed">'
            body += "<span style='display:inline-block; width: 0;" +
                "height: 0;" +
                "border-style: solid;" +
                "border-width: 10px 7px 0 7px;" +
                "border-color: #fff transparent transparent transparent; margin-right: 10px'></span>";
            body += 'more</span>';
            body += '<span class="opened">'
            body += "<span style='display:inline-block; width: 0;" +
                "height: 0;" +
                "border-style: solid;" +
                "border-width: 0 7px 10px 7px;" +
                "border-color: transparent transparent #fff transparent; margin-right: 10px'></span>";
            body += 'less</span>';
            body += '</a>';
        }
        return body;
    }

    function registerRenderer() {
        var overrideCtx = {};
        overrideCtx.Templates = {};
        overrideCtx.Templates.Header = customHeader;
        overrideCtx.Templates.Footer = "<div style='border-bottom: 3px #eee solid'></div></div>";
        //overrideCtx.Templates.Item = customTitle;
        overrideCtx.Templates.Body = customBody;
        SPClientTemplates.TemplateManager.RegisterTemplateOverrides(overrideCtx);
        //$('.collapse').collapse();
    }

    ExecuteOrDelayUntilScriptLoaded(registerRenderer, 'clienttemplates.js');
})();