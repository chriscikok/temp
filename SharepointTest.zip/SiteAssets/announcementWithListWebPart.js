window.onload = function(){
		var announcementDiv = document.getElementById("test-announcement");
		var table = document.querySelector("table[summary=Carousel]");
		var tableBody = table.querySelector("tbody");
		for (let i = 0; i < 3; i++){
			if (i == tableBody.children.length)
				return;
			var row = document.createElement("div");
			row.setAttribute("class", "divTableRow");
			var column = document.createElement("div");
			column.setAttribute("class", "divTableCell");
			var rightArrow = document.createElement("span");
			rightArrow.setAttribute("class", "red-right-arrow");
			rightArrow.innerHTML = "▶";
			var aTag = document.createElement("a");
			aTag.innerHTML = tableBody.children[i].children[1].children[0].children[0].innerHTML;
			aTag.onclick = function(){
				alert(tableBody.children[i].children[3].innerHTML);
			};
			aTag.href="javascript:";
			column.append(rightArrow);
			column.append(aTag);
			row.append(column);
			announcementDiv.append(row);		
		}
		var collapseAnnounments = document.getElementById("collapseAnnounments");
		for (let i = 3; i < tableBody.children.length; i++){
			var row = document.createElement("div");
			row.setAttribute("class", "divTableRow");
			var column = document.createElement("div");
			column.setAttribute("class", "divTableCell");
			var rightArrow = document.createElement("span");
			rightArrow.setAttribute("class", "red-right-arrow");
			rightArrow.innerHTML = "▶";
			var aTag = document.createElement("a");
			aTag.innerHTML = tableBody.children[i].children[1].children[0].children[0].innerHTML;
			aTag.onclick = function(){
				alert(tableBody.children[i].children[3].innerHTML);
			};
			aTag.href="javascript:";
			column.append(rightArrow);
			column.append(aTag);
			row.append(column);
			collapseAnnounments.append(row);		
		}
	}
	
	function changeAnnouncements(e){
		if (e.currentTarget.innerHTML == "▼ Show")
			e.currentTarget.innerHTML = "▲ Hide";
		else if (e.currentTarget.innerHTML == "▲ Hide")
			e.currentTarget.innerHTML = "▼ Show";
	}