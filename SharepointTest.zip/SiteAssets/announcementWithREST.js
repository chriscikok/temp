$.ajax({
	url: "http://192.168.0.104:10001/_api/web/lists/GetByTitle('Carousel')/items", // ur site url goes here
	type: "GET",
	headers: {
		"Accept": "application/json;odata=verbose"
	},
	success: function(data) {
		var results = data.d.results;
		var announcementDiv = document.getElementById("test-announcement");
		for (let i = 0; i < 3; i++){
			if (i == results.length)
				return;
			var row = document.createElement("div");
			row.setAttribute("class", "divTableRow");
			var column = document.createElement("div");
			column.setAttribute("class", "divTableCell");
			var rightArrow = document.createElement("span");
			rightArrow.setAttribute("class", "red-right-arrow");
			rightArrow.innerHTML = "▶";
			var aTag = document.createElement("a");
			aTag.innerHTML = results[i].Title;
			aTag.onclick = function(){
				alert(results[i].Description);
			};
			aTag.href="javascript:";
			column.append(rightArrow);
			column.append(aTag);
			row.append(column);
			announcementDiv.append(row);		
		}
		var collapseAnnounments = document.getElementById("collapseAnnounments");
		for (let i = 3; i < results.length; i++){
			var row = document.createElement("div");
			row.setAttribute("class", "divTableRow");
			var column = document.createElement("div");
			column.setAttribute("class", "divTableCell");
			var rightArrow = document.createElement("span");
			rightArrow.setAttribute("class", "red-right-arrow");
			rightArrow.innerHTML = "▶";
			var aTag = document.createElement("a");
			aTag.innerHTML = results[i].Title;
			aTag.onclick = function(){
				alert(results[i].Description);
			};
			aTag.href="javascript:";
			column.append(rightArrow);
			column.append(aTag);
			row.append(column);
			collapseAnnounments.append(row);		
		}
		console.log("haha!");
	},
	error: function r(xhr) {
		alert("error:" + JSON.stringify(xhr));
	}
	// i am adding the carousel after the rest call that way you avoid the flickering delay in the images
})
function changeAnnouncements(e){
	if (e.currentTarget.innerHTML == "▼ Show")
		e.currentTarget.innerHTML = "▲ Hide";
	else if (e.currentTarget.innerHTML == "▲ Hide")
		e.currentTarget.innerHTML = "▼ Show";
}